package com.COS216.u18171185;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.*;
import android.widget.*;
import android.content.Intent;
import com.COS216.u18171185.R;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.PasswordAuthentication;
import java.net.URL;

public class FilterOptionsFragment extends Fragment {

    Activity activity;

    Spinner spnGenre;
    Spinner spnYear;
    Spinner spnRating;
    
    ArrayAdapter adapter_g_names;
    ArrayAdapter adapter_g_ids;
    ArrayAdapter adapter_y;
    ArrayAdapter adapter_r;
    
    Button btnApplyFilter;
    Button btnSaveFilter;

    TextView txt;

    @Nullable @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState){
        View fragmentView = inflater.inflate(R.layout.filter_options, container, false);

        activity = getActivity();

        btnApplyFilter = fragmentView.findViewById(R.id.btnFilterApply);
        btnApplyFilter.setOnClickListener(btnApplyFilterClickListener);

        btnSaveFilter = fragmentView.findViewById(R.id.btnFilterSave);
        btnSaveFilter.setOnClickListener(btnSaveFilterClickListener);

        spnGenre = fragmentView.findViewById(R.id.spnFilterGenre);
        spnYear = fragmentView.findViewById(R.id.spnFilterYear);
        spnRating = fragmentView.findViewById(R.id.spnFilterRating);

        txt = fragmentView.findViewById(R.id.txtFilterGenre);

        adapter_g_names = ArrayAdapter.createFromResource(activity, R.array.filterGenresNames, R.layout.spinner_item);
        adapter_g_names.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spnGenre.setAdapter(adapter_g_names);
        adapter_g_ids = ArrayAdapter.createFromResource(activity, R.array.filterGenresIDs, R.layout.spinner_item);
        
        adapter_y = ArrayAdapter.createFromResource(activity, R.array.filterYears, R.layout.spinner_item);
        adapter_y.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spnYear.setAdapter(adapter_y);
    
        adapter_r = ArrayAdapter.createFromResource(activity, R.array.filterRatings, R.layout.spinner_item);
        adapter_r.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spnRating.setAdapter(adapter_r);
    
        loadPreferences();
        
        return fragmentView;
    }
    
    public void loadPreferences(){
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(((MainActivity)getActivity()).getApplicationContext());
    
        String genre_id = sharedPref.getString(getString(R.string.key_Genre),getString(R.string.notLoggedIn));
        String year = sharedPref.getString(getString(R.string.key_Year),getString(R.string.notLoggedIn));
        String rating = sharedPref.getString(getString(R.string.key_Rating),getString(R.string.notLoggedIn));
    
       if (!genre_id.equals(getString(R.string.notLoggedIn))) {
            int pos = adapter_g_ids.getPosition(genre_id);
            if(pos < 0){ pos = 0;}
            String name = getGenreName(pos);
            pos = adapter_g_names.getPosition(name);
            if(pos < 0){ pos = 0;}
            spnGenre.setSelection(pos);
        }
    
        if (!year.equals(getString(R.string.notLoggedIn))) {
            int pos = adapter_y.getPosition(year);
            if(pos < 0){ pos = 0;}
            spnYear.setSelection(pos);
        }
    
        if (!rating.equals(getString(R.string.notLoggedIn))) {
            int pos = adapter_r.getPosition(rating);
            if(pos < 0){ pos = 0;}
            spnRating.setSelection(pos);
        }
    }
    
    public String getGenreID(int index){
        if(index == 1){
            SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(((MainActivity)getActivity()).getApplicationContext());
            String genre_id = sharedPref.getString(getString(R.string.key_Genre),getString(R.string.notLoggedIn));
            if(!genre_id.equals(getString(R.string.notLoggedIn))){
                index = adapter_g_ids.getPosition(genre_id);
                if(index < 2){ index = 0;}
            }else{
                index =0;
            }
        }
        return getResources().getStringArray(R.array.filterGenresIDs)[index];
    }
    
    public String getGenreName(int index){
        return getResources().getStringArray(R.array.filterGenresNames)[index];
    }
    
    
    public String getYear(int index){
        if(index == 1){
            SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(((MainActivity)getActivity()).getApplicationContext());
            String year = sharedPref.getString(getString(R.string.key_Year),getString(R.string.notLoggedIn));
            if(!year.equals(getString(R.string.notLoggedIn))){
                index = adapter_y.getPosition(year);
                if(index < 2){ index = 0;}
            }else{
                index =0;
            }
        }
        return getResources().getStringArray(R.array.filterYears)[index];
    }
    
    public String getRating(int index){
        if(index == 1){
            SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(((MainActivity)getActivity()).getApplicationContext());
            String rating = sharedPref.getString(getString(R.string.key_Rating),"null");
            if(!rating.equals("null")){
                index = adapter_r.getPosition(rating);
                if(index < 2){ index = 0;}
            }else{
                index =0;
            }
        }
        return getResources().getStringArray(R.array.filterRatings)[index];
    }
    
    private Button.OnClickListener btnApplyFilterClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Fragment discFrag = ((MainActivity)getActivity()).getSupportFragmentManager().findFragmentByTag("Discover");
            if(discFrag != null){
               
    
                String genreID = getGenreID(spnGenre.getSelectedItemPosition());
                String year = getYear(spnYear.getSelectedItemPosition());
                String rating = getRating(spnRating.getSelectedItemPosition());
    
                ((DiscoverFragment)discFrag).btnFilter.callOnClick();
                ((DiscoverFragment)discFrag).Refresh(genreID,year,rating);
            }
        }
    };

    private Button.OnClickListener btnSaveFilterClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String genreID = getGenreID(spnGenre.getSelectedItemPosition());
            String year = getYear(spnYear.getSelectedItemPosition());
            String rating = getRating(spnRating.getSelectedItemPosition());
    
            SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(((MainActivity)getActivity()).getApplicationContext());
            String apikey = sharedPref.getString(getString(R.string.key_ApiKey),"null");
    
            UpdatePreferences updatePreferences = new UpdatePreferences(apikey, genreID,year,rating);
            updatePreferences.execute();
        }
    };
    
    public void makeToast(String msg){
        Toast.makeText(((MainActivity)getActivity()).getApplicationContext(),msg,Toast.LENGTH_SHORT).show();
    }
    
    class UpdatePreferences extends AsyncTask<String, Void, String> {
        String genre_ID;
        String year;
        String rating;
        String apikey;
        boolean success = false;
        JSONObject responseOBJ;
        
        public UpdatePreferences(String A, String ID, String Y, String R){
            this.apikey = A;
            this.genre_ID = ID;
            this.year = Y;
            this.rating = R;
        }
        @Override protected void onPreExecute() {
            super.onPreExecute();
            /* TODO: display loading Animation */
        }
        @Override protected String doInBackground(String... urls) {
            
            /* TODO: prepare post parms */
            /* TODO: make post request */
            
            Log.d("PREF_GENRE",genre_ID);
            Log.d("PREF_YEAR",year);
            Log.d("PREF_RATING",rating);
            
            Authenticator.setDefault(new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication(){
                    return new PasswordAuthentication(getString(R.string.wheatley_username)
                            ,getString(R.string.wheatley_password).toCharArray());
                }
            });
            
            String postParms = "type=update&key="+apikey+"&pref_Genre="+genre_ID+"&pref_Year="+year+"&pref_Rating="+rating;
            
            success =  attempt(postParms);
            
            return "";
        }
        private Boolean attempt(String postParms) {
            //check via http request to API if login is valid
            String response;
            URL url;
            try {
                url = new URL(getString(R.string.api_url));
            } catch (MalformedURLException e) {
                Log.e("setUrl", Log.getStackTraceString(e));
                return false;
            }
            success = false;
            
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) url.openConnection();
                
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                
                OutputStream out = connection.getOutputStream();
                writeStream(out, postParms);
                
                connection.connect();
                
                Log.d("ResponseCode2",Integer.toString(connection.getResponseCode()));
                
                InputStream in;
                
                if(connection.getResponseCode() == HttpURLConnection.HTTP_OK){
                    in= new BufferedInputStream(connection.getInputStream());
                }
                else{
                    in = new BufferedInputStream(connection.getErrorStream());
                }
                
                response = readStream(in);
                Log.e("RESPONSE", response);
                
                responseOBJ = new JSONObject(response);
                
                if(responseOBJ.getString("status").equals("success")){
                    success = true;
                } else {
                    success = false;
                }
                
            } catch (Exception e) {
                Log.e("httpTest", Log.getStackTraceString(e));
                success = false;
            } finally {
                
                if (connection != null) {
                    connection.disconnect();
                }
            }
            return success;
        }
        
        @Override protected void onPostExecute(String response) {
            if(responseOBJ == null){
                Log.e("JSON","responseOBJ is NULL");
                makeToast(getString(R.string.serverErrorMessage));
                return;
            }
            
            if (success) {
                SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(((MainActivity)getActivity()).getApplicationContext());
                SharedPreferences.Editor editor = sharedPref.edit();
                
                editor.putString(getString(R.string.key_Genre),genre_ID);
                editor.putString(getString(R.string.key_Rating),rating);
                editor.putString(getString(R.string.key_Year),year);
                
                editor.commit();
    
                makeToast(getString(R.string.PreferencesSavedSuccessfully));
            } else {
                //login failed
                makeToast(getString(R.string.serverErrorMessage));
            }
        }
        
        private void writeStream(OutputStream out, String parms) throws IOException {
            BufferedWriter writer = new BufferedWriter(
                    new OutputStreamWriter(out, "UTF-8"));
            writer.write(parms);
            writer.flush();
            writer.close();
        }
        private String readStream(InputStream ins) throws IOException {
            BufferedReader in = new BufferedReader(new InputStreamReader(ins));
            String result = "";
            String response;
            int i = 0;
            while ((response = in.readLine()) != null){
                result = result + response;
            }
            in.close();
            return result;
        }
        
    }
}
