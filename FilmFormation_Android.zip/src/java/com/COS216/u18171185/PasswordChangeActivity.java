package com.COS216.u18171185;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.*;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.PasswordAuthentication;
import java.net.URL;

public class PasswordChangeActivity extends AppCompatActivity {
	
	EditText edtOld;
	EditText edtNew;
	EditText edtRepeat;
	
	ImageButton btnOldToggle;
	ImageButton btnNewToggle;
	ImageButton btnRepeatToggle;
	
	Button btnSave;
	Button btnCancel;
	ImageButton btnBack;
	
	TextView changeFailed;
	
	boolean Old = true;
	boolean New = true;
	boolean Repeat = true;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_password_change);
		
		edtOld = findViewById(R.id.edtPassOld);
		edtOld.setOnFocusChangeListener(OldOnFocus);
		edtOld.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
		
		edtNew = findViewById(R.id.edtPassNew);
		edtNew.setOnFocusChangeListener(NewOnFocus);
		edtNew.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
		
		edtRepeat = findViewById(R.id.edtPassRepeat);
		edtRepeat.setOnFocusChangeListener(RepeatOnFocus);
		edtRepeat.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
		
		btnOldToggle = findViewById(R.id.btnPassOldToggle);
		btnOldToggle.setImageResource(R.drawable.ic_visibility);
		btnOldToggle.setOnClickListener(btnOldTogglePasswordOnClick);
		
		btnNewToggle = findViewById(R.id.btnPassNewToggle);
		btnNewToggle.setImageResource(R.drawable.ic_visibility);
		btnNewToggle.setOnClickListener(btnNewTogglePasswordOnClick);
		
		btnRepeatToggle = findViewById(R.id.btnPassRepeatToggle);
		btnRepeatToggle.setImageResource(R.drawable.ic_visibility);
		btnRepeatToggle.setOnClickListener(btnRepeatTogglePasswordOnClick);
		
		btnSave = findViewById(R.id.btnPassApply);
		btnSave.setOnClickListener(btnSaveOnClick);
		
		btnCancel = findViewById(R.id.btnPassCancel);
		btnCancel.setOnClickListener(btnBackOnClick);
		
		btnBack = findViewById(R.id.btnPassBack);
		btnBack.setOnClickListener(btnBackOnClick);
		
		changeFailed = findViewById(R.id.txtChangeFailed);
	}
	
	Button.OnClickListener btnSaveOnClick = new View.OnClickListener(){
		@Override public void onClick(View v) {
			String oldText = edtOld.getText().toString();
			String newText = edtNew.getText().toString();
			String repeatText = edtRepeat.getText().toString();
			
			if(newText.equals(repeatText))
			{
				SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
				
				String apikey = sharedPref.getString(getString(R.string.key_ApiKey), getString(R.string.notLoggedIn));
				if(!apikey.equals(getString(R.string.notLoggedIn)))
				{
					changeFailed.setText("");
					ChangePassword cp = new ChangePassword(apikey, oldText, newText);
					cp.execute();
				}else{
					changeFailed.setText(R.string.notLoggedIn);
				}
			}else{
				changeFailed.setText(R.string.duplicatePasswords);
			}
			
		}
	};
	
	Button.OnClickListener btnBackOnClick = new View.OnClickListener(){
		@Override public void onClick(View v) {
			finish();
		}
	};
	EditText.OnFocusChangeListener OldOnFocus = new View.OnFocusChangeListener(){
		@Override
		public void onFocusChange(View v, boolean hasFocus) {if(hasFocus){
				btnOldToggle.setVisibility(View.VISIBLE);
			}else{
				btnOldToggle.setVisibility(View.GONE);
			}}
	};
	EditText.OnFocusChangeListener NewOnFocus = new View.OnFocusChangeListener(){
		@Override
		public void onFocusChange(View v, boolean hasFocus) {if(hasFocus){
				btnNewToggle.setVisibility(View.VISIBLE);
			}else{
				btnNewToggle.setVisibility(View.GONE);
			}}
	};
	EditText.OnFocusChangeListener RepeatOnFocus = new View.OnFocusChangeListener(){
		@Override
		public void onFocusChange(View v, boolean hasFocus) {if(hasFocus){
				btnRepeatToggle.setVisibility(View.VISIBLE);
			}else{
				btnRepeatToggle.setVisibility(View.GONE);
			}}};
	ImageButton.OnClickListener btnOldTogglePasswordOnClick = new View.OnClickListener() {
		@Override public void onClick(View v) {
			if(Old){
				btnOldToggle.setImageResource(R.drawable.ic_visibility_off);
				edtOld.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
			}else{
				btnOldToggle.setImageResource(R.drawable.ic_visibility);
				edtOld.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
			}
			edtOld.setSelection(edtOld.length());
			Old = !Old;
		}
	};
	ImageButton.OnClickListener btnNewTogglePasswordOnClick = new View.OnClickListener() {
		@Override public void onClick(View v) {
			if(New){
				btnNewToggle.setImageResource(R.drawable.ic_visibility_off);
				edtNew.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
			}else{
				btnNewToggle.setImageResource(R.drawable.ic_visibility);
				edtNew.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
			}
			edtNew.setSelection(edtNew.length());
			New = !New;
		}
	};
	ImageButton.OnClickListener btnRepeatTogglePasswordOnClick = new View.OnClickListener() {
		@Override public void onClick(View v) {
			if(Repeat){
				btnRepeatToggle.setImageResource(R.drawable.ic_visibility_off);
				edtRepeat.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
			}else{
				btnRepeatToggle.setImageResource(R.drawable.ic_visibility);
				edtRepeat.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
			}
			edtRepeat.setSelection(edtRepeat.length());
			Repeat = !Repeat;
		}
	};
	
	class ChangePassword extends AsyncTask<String, Void, String> {
		
		String oldPassword;
		String newPassword;
		String apikey;
		
		boolean success = false;
		
		JSONObject responseOBJ;
		
		public ChangePassword(String A, String O, String N){
			oldPassword = O;
			newPassword = N;
			apikey = A;
		}
		
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			/* TODO: display loading Animation */
		}
		
		@Override
		protected String doInBackground(String... urls) {
			
			/* TODO: prepare post parms */
			/* TODO: make post request */
			
			Log.d("OLD PASSWORD",oldPassword);
			Log.d("NEW PASSWORD",newPassword);
			
			Authenticator.setDefault(new Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication(){
					return new PasswordAuthentication(getString(R.string.wheatley_username)
							,getString(R.string.wheatley_password).toCharArray());
				}
			});
			
			success =  attempt(apikey, oldPassword, newPassword);
			
			return "";
		}
		
		@Override
		protected void onPostExecute(String response) {
			if(responseOBJ == null){
				Log.e("JSON","responseOBJ is NULL");
				changeFailed.setText(R.string.serverErrorMessage);
				return;
			}
			if (success) {
				changeFailed.setText("");
				finish();
			} else {
				changeFailed.setText(R.string.passwordIncorrect);
			}
		}
		
		private Boolean attempt(String apiKey, String oldPass, String newPass) {
			//check via http request to API if login is valid
			String postParms = "type=changePassword&old="+oldPass+"&new="+newPass+"&key="+apiKey;
			
			Log.e("PARMS", postParms);
			
			String response;
			URL url;
			try {
				url = new URL(getString(R.string.api_url));
			} catch (MalformedURLException e) {
				Log.e("setUrl", Log.getStackTraceString(e));
				return false;
			}
			success = false;
			
			HttpURLConnection connection = null;
			try {
				connection = (HttpURLConnection) url.openConnection();
				
				connection.setRequestMethod("POST");
				connection.setRequestProperty("Content-Type", "application/json");
				
				OutputStream out = connection.getOutputStream();
				writeStream(out, postParms);
				
				connection.connect();
				
				Log.d("ResponseCode2",Integer.toString(connection.getResponseCode()));
				
				InputStream in;
				
				if(connection.getResponseCode() == HttpURLConnection.HTTP_OK){
					in= new BufferedInputStream(connection.getInputStream());
				}
				else{
					in = new BufferedInputStream(connection.getErrorStream());
				}
				response = readStream(in);
				Log.e("RESPONSE", response);
				
				responseOBJ = new JSONObject(response);
				
				if(responseOBJ.getString("status").equals("success")){
					success = true;
				} else {
					success = false;
				}
				
			} catch (Exception e) {
				Log.e("httpTest", Log.getStackTraceString(e));
				success = false;
			} finally {
				
				if (connection != null) {
					connection.disconnect();
				}
			}
			return success;
		}
		
		private void writeStream(OutputStream out, String parms) throws IOException {
			BufferedWriter writer = new BufferedWriter(
					new OutputStreamWriter(out, "UTF-8"));
			writer.write(parms);
			writer.flush();
			writer.close();
		}
		private String readStream(InputStream ins) throws IOException {
			BufferedReader in = new BufferedReader(new InputStreamReader(ins));
			String result = "";
			String response;
			while ((response = in.readLine()) != null) result = result + response;
			in.close();
			return result;
		}
		
	}
	
	
}
