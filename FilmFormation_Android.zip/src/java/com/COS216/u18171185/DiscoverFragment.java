package com.COS216.u18171185;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.*;
import android.widget.*;
import android.content.Intent;
import com.COS216.u18171185.R;
import org.json.*;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.PasswordAuthentication;
import java.net.URL;
import java.util.ArrayList;

public class DiscoverFragment extends Fragment {

    Activity activity;

    public Button btnFilter;
    View filterOptions;
    TextView txtResults;
    
    private boolean filterClicked = false;
    
    String apikey_main;
    String genre_main;
    String year_main;
    String rating_main;
    
    ArrayAdapter adapter_g_names;
    ArrayAdapter adapter_g_ids;
    ArrayAdapter adapter_y;
    ArrayAdapter adapter_r;
    
    @Nullable @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState){
        View fragmentView = inflater.inflate(R.layout.discover_layout, container, false);

        activity = getActivity();
        
        FragmentManager fragmentManager = ((FragmentActivity) activity).getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        Fragment fragment = new FilterOptionsFragment();
        fragmentTransaction.add(R.id.grpDiscoverBody, fragment, "Filter");
        fragmentTransaction.addToBackStack("Filter");
        fragmentTransaction.hide(fragment);
        fragmentTransaction.commit();
    
        filterOptions = fragmentView.findViewById(R.id.grpFilterOptions);
        filterOptions.setVisibility(View.GONE);
        
        btnFilter = fragmentView.findViewById(R.id.grpDiscoverBody).findViewById(R.id.btnFilter);
        btnFilter.setOnClickListener(toggleViewListener);
    
        txtResults = fragmentView.findViewById(R.id.txtResults);
        txtResults.setText("");
        txtResults.setVisibility(View.GONE);
    
        adapter_g_names = ArrayAdapter.createFromResource(((FragmentActivity)getActivity()), R.array.filterGenresNames, R.layout.spinner_item);
        adapter_g_ids = ArrayAdapter.createFromResource(((FragmentActivity)getActivity()), R.array.filterGenresIDs, R.layout.spinner_item);
        adapter_y = ArrayAdapter.createFromResource(((FragmentActivity)getActivity()), R.array.filterYears, R.layout.spinner_item);
        adapter_r = ArrayAdapter.createFromResource(((FragmentActivity)getActivity()), R.array.filterRatings, R.layout.spinner_item);
        
        Refresh();
        
        return fragmentView;
    }
    
    public String getGenreID(int index){
        if(index == 1){
            SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(((FragmentActivity)getActivity()).getApplicationContext());
            String genre_id = sharedPref.getString(getString(R.string.key_Genre),"null");
            if(!genre_id.equals("null")){
                index = adapter_g_ids.getPosition(genre_id);
                if(index < 2){ index = 0;}
            }else{
                index =0;
            }
        }
        return getResources().getStringArray(R.array.filterGenresIDs)[index];
    }
    
    public String getGenreName(int index){
        return getResources().getStringArray(R.array.filterGenresNames)[index];
    }
    
    
    public String getYear(int index){
        if(index == 1){
            SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(((FragmentActivity)getActivity()).getApplicationContext());
            String year = sharedPref.getString(getString(R.string.key_Year),"null");
            if(!year.equals("null")){
                index = adapter_y.getPosition(year);
                if(index < 2){ index = 0;}
            }else{
                index =0;
            }
        }
        return getResources().getStringArray(R.array.filterYears)[index];
    }
    
    public String getRating(int index){
        if(index == 1){
            SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(((FragmentActivity)getActivity()).getApplicationContext());
            String rating = sharedPref.getString(getString(R.string.key_Rating),"null");
            if(!rating.equals("null")){
                index = adapter_r.getPosition(rating);
                if(index < 2){ index = 0;}
            }else{
                index =0;
            }
        }
        return getResources().getStringArray(R.array.filterRatings)[index];
    }
    
	private Button.OnClickListener toggleViewListener = new View.OnClickListener(){
        @Override  public void onClick(View v) {
           
            FragmentManager fragmentManager = ((FragmentActivity) activity).getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            Fragment fragment = ((FragmentActivity) activity).getSupportFragmentManager().findFragmentByTag("Filter");
            filterClicked = !filterClicked;
            if(filterClicked){ //Open Filter Dialog
                btnFilter.setText(R.string.filter_Close);
                fragmentTransaction.show(fragment);
            }else{//Close Filter Dialog
                btnFilter.setText(R.string.filter_Title);
                fragmentTransaction.hide(fragment);
            }
            fragmentTransaction.commit();
        }
    };

    public void generateMovieFragments(int count){
        for(int i = 0; i< count; i++)
        {
            //addMovieFragment();
        }
    }
    
    public void addMovieFragment(String tmdbID,String title,String poster,String release,String genre,String rating,String ageRating,String plot)
    {
        FragmentManager fragmentManager = ((FragmentActivity) activity).getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        
        Bundle bundle = new Bundle();
		bundle.putString("tmdbID", tmdbID);
        bundle.putString("title", title);
        bundle.putString("poster", poster);
        bundle.putString("release", release);
        bundle.putString("genre", genre);
        bundle.putString("rating", rating);
        bundle.putString("ageRating", ageRating);
        bundle.putString("plot", plot);
        
		Fragment fragment = new MovieFragment();
		fragment.setArguments(bundle);
		
		fragmentTransaction.add(R.id.grpDiscoverBody, fragment, "Movie");
        fragmentTransaction.addToBackStack("Movie");
		fragmentTransaction.commit();
    }
    
    public void removeMovies(){
        for (Fragment fragment:((FragmentActivity) activity).getSupportFragmentManager().getFragments()) {
            if (fragment!=null && fragment.getTag().equals("Movie")) {
                ((FragmentActivity) activity).getSupportFragmentManager().beginTransaction().remove(fragment).commit();
            }
        }
    }
    
    public void loadFilters(){
        Fragment filter = ((FragmentActivity)activity).getSupportFragmentManager().findFragmentByTag("Filter");
        if(filter != null){
            ((FilterOptionsFragment)filter).loadPreferences();
        }
    }
    
    public void makeToast(String msg){
        Toast.makeText(((FragmentActivity) activity).getApplicationContext(),msg,Toast.LENGTH_SHORT).show();
    }
    
    public void Refresh(){
    
    	makeToast("XXXxxxx");
    	
        if(((MainActivity)getActivity()).isLoggedIn()){
            SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(((MainActivity)getActivity()).getApplicationContext());
        
            apikey_main = sharedPref.getString(getString(R.string.key_ApiKey), getString(R.string.notLoggedIn));
            genre_main = sharedPref.getString(getString(R.string.key_Genre), getString(R.string.notLoggedIn));
            year_main = sharedPref.getString(getString(R.string.key_Year), getString(R.string.notLoggedIn));
            rating_main = sharedPref.getString(getString(R.string.key_Rating), getString(R.string.notLoggedIn));
    
            Refresh(apikey_main,genre_main,year_main,rating_main);
        }
        else{
            txtResults.setText(R.string.notLoggedIn);
        }
    }
    
    public void Refresh(String genre, String year, String rating){
        
        if(((MainActivity)getActivity()).isLoggedIn()){
            SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(((MainActivity)getActivity()).getApplicationContext());
            
            apikey_main = sharedPref.getString(getString(R.string.key_ApiKey), getString(R.string.notLoggedIn));
            genre_main = genre;
            year_main = year;
            rating_main = rating;
            
            Refresh(apikey_main,genre_main,year_main,rating_main);
        }
        else{
            txtResults.setText(R.string.notLoggedIn);
        }
    }
    
    public void Refresh(String apikey, String genre, String year, String rating){
        removeMovies();
        RefreshTask refreshTask = new RefreshTask(apikey, genre, year, rating);
        refreshTask.execute();
    }
    
    public String getGenreList(JSONArray arr)
    {
        try {
            String list = "";
            for (int i = 0; i < arr.length(); i++) {
                String genre_names = arr.getString(i);
                list = list + ", " + genre_names;
            }
            return list.substring(2);
        }catch(Exception e){
            Log.e("JSON",Log.getStackTraceString(e));
        }
        return "N/A";
    }
    
    class RefreshTask extends AsyncTask<String, Void, String> {
        String Apikey;
        String Genre;
        String Year;
        String Rating;
        boolean success = false;
        JSONObject responseOBJ;
        
        public RefreshTask(String apikey, String genre, String year, String rating){
            Apikey = apikey;
            Genre = genre;
            Year = year;
            Rating = rating;
        }
        @Override protected void onPreExecute() {
            super.onPreExecute();
            
            /* TODO: display loading Animation */
            txtResults.setText(R.string.Refreshing);
            txtResults.setVisibility(View.VISIBLE);
        }
        @Override protected String doInBackground(String... urls) {
            
            /* TODO: prepare post parms */
            /* TODO: make post request */
            
            Log.d("APIKEY",Apikey);
            Log.d("GENRE",Genre);
            Log.d("RATING",Rating);
            Log.d("YEAR",Year);
    
            if(Year.equals("No Filter")) { Year=""; }
            if(Rating.equals("No Filter")){ Rating=""; }
            if(Genre.equals("No Filter")) { Genre=""; }
            
            Authenticator.setDefault(new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication(){
                    return new PasswordAuthentication(getString(R.string.wheatley_username)
                            ,getString(R.string.wheatley_password).toCharArray());
                }
            });
            
            String postParms = "type=info&key="+Apikey;
            
            if(Year.length() > 0) { postParms = postParms + "&year="+Year; }
            if(Rating.length() > 0){ postParms = postParms + "&rating="+Rating;  }
            if(Genre.length() > 0) { postParms = postParms + "&genre="+Genre; }
            /*
            postParms += "&year="+Year;
            postParms += "&year="+Year;
            postParms += "&genre="+Genre;
            */
            postParms = postParms + "&return[]=title&return[]=genre&return[]=poster&return[]=release&return[]=ageRestriction&return[]=rating&return[]=synopsis&return[]=tmdbID";
            
            success =  attempt(postParms);
            
            return "";
        }
        private Boolean attempt(String postParms) {
            //check via http request to API if login is valid
            String response;
            URL url;
            try {
                url = new URL(getString(R.string.api_url));
            } catch (MalformedURLException e) {
                Log.e("setUrl", Log.getStackTraceString(e));
                return false;
            }
            success = false;
            
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) url.openConnection();
                
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                
                OutputStream out = connection.getOutputStream();
                writeStream(out, postParms);
                
                connection.connect();
                
                Log.d("ResponseCode2",Integer.toString(connection.getResponseCode()));
                
                InputStream in;
                
                if(connection.getResponseCode() == HttpURLConnection.HTTP_OK){
                    in= new BufferedInputStream(connection.getInputStream());
                }
                else{
                    in = new BufferedInputStream(connection.getErrorStream());
                }
                response = readStream(in);
                Log.e("RESPONSE", response);
                
                responseOBJ = new JSONObject(response);
                
                if(responseOBJ.getString("status").equals("success")){
                    success = true;
                } else {
                    success = false;
                }
                
            } catch (Exception e) {
                Log.e("httpTest", Log.getStackTraceString(e));
                success = false;
            } finally {
                
                if (connection != null) {
                    connection.disconnect();
                }
            }
            return success;
        }
        @Override protected void onPostExecute(String response) {
            if(responseOBJ == null){
                Log.e("JSON","responseOBJ is NULL");
                txtResults.setText(R.string.serverErrorMessage);
                return;
            }
            
            if (success) {
                try {
                    JSONArray data = responseOBJ.getJSONArray("data");
                    
                    if(data.length() <= 0) {
                        txtResults.setText(R.string.NoResults);
                        txtResults.setVisibility(View.VISIBLE);
                    }
                    else{
                        for(int i = 0; i < data.length(); i++)
                        {
                            JSONObject obj = data.getJSONObject(i);
    
                            String tmdbID = obj.getString("tmdbID");
                            String title = obj.getString("title");
                            String posterURL = obj.getString("poster");
                            String released = obj.getString("release");
                            String genre = getGenreList(obj.getJSONArray("genre"));
                            String rating = "Rating: " + "X/10";//obj.getString("title");
                            String ageRating = "";//obj.getString("ageRestriction");
                            String plot = obj.getString("synopsis");
                            
                            addMovieFragment(tmdbID,title,posterURL,released,genre,rating,ageRating,plot);
                            txtResults.setText("");
                            txtResults.setVisibility(View.GONE);
                        }
                    }
                }
                catch(Exception e){
                    Log.e("JSON",Log.getStackTraceString(e));
                    txtResults.setText(R.string.serverErrorMessage);
                    txtResults.setVisibility(View.VISIBLE);
                }
            } else {
                //login failed
                txtResults.setText(R.string.serverErrorMessage);
                txtResults.setVisibility(View.VISIBLE);
            }
        }
        
        private void writeStream(OutputStream out, String parms) throws IOException {
            BufferedWriter writer = new BufferedWriter(
                    new OutputStreamWriter(out, "UTF-8"));
            writer.write(parms);
            writer.flush();
            writer.close();
        }
        private String readStream(InputStream ins) throws IOException {
            BufferedReader in = new BufferedReader(new InputStreamReader(ins));
            String result = "";
            String response;
            while ((response = in.readLine()) != null) result = result + response;
            in.close();
            return result;
        }
        
    }
    
}
