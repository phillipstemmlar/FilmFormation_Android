package com.COS216.u18171185;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.*;
import android.view.*;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.PasswordAuthentication;
import java.net.URL;

public class SettingsActivity extends AppCompatActivity {
	
	Button btnApply;
	Button btnCancel;
	Button btnPassword;
	ImageButton btnBack;
	
	EditText edtEmail;
	CheckBox cbxStayLoggedIn;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_settings);
		
		btnApply = findViewById(R.id.btnSettingsApply);
		btnApply.setOnClickListener(btnApplyClickListener);
		
		btnCancel = findViewById(R.id.btnSettingsCancel);
		btnCancel.setOnClickListener(btnBackOnClickListener);
		
		btnBack = findViewById(R.id.btnSettingsBack);
		btnBack.setOnClickListener(btnBackOnClickListener);
		
		btnPassword = findViewById(R.id.btnChangePassword);
		btnPassword.setOnClickListener(btnPasswordOnClickListener);
		
		edtEmail = findViewById(R.id.edtSettingsEmail);
		cbxStayLoggedIn = findViewById(R.id.cbxSettingsKeepMeLoggedIn);
		
		/* TODO: if logged in load settings into email and checkbox */
		
		SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
		
		String Email = sharedPref.getString(getString(R.string.key_Email),"null");
		Boolean stayLoggedIn = sharedPref.getBoolean(getString(R.string.key_KeepMeLoggedIn),false);
		
		edtEmail.setText(Email);
		cbxStayLoggedIn.setChecked(stayLoggedIn);
	}
	
	private Button.OnClickListener btnApplyClickListener = new View.OnClickListener() {
		@Override public void onClick(View v) {
			SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
			
			String Email = sharedPref.getString(getString(R.string.key_Email),"null");
			String Apikey = sharedPref.getString(getString(R.string.key_ApiKey),"null");
			Boolean stayLoggedIn = sharedPref.getBoolean(getString(R.string.key_KeepMeLoggedIn),false);
			
			SharedPreferences.Editor editor = sharedPref.edit();
			editor.putBoolean(getString(R.string.key_KeepMeLoggedIn), cbxStayLoggedIn.isChecked());
			editor.commit();
			
			
			if(!Email.equals(edtEmail.getText().toString())){
				UpdateEmail updateEmail = new UpdateEmail(Apikey,edtEmail.getText().toString());
				updateEmail.execute();
			}
			else{
				makeToast(getString(R.string.SettingsSavedSuccessfully));
				
				finish();
			}
			
		}
	};
	
	private Button.OnClickListener btnPasswordOnClickListener = new View.OnClickListener() {
		@Override public void onClick(View v) {
			Intent intent = new Intent(SettingsActivity.this, PasswordChangeActivity.class);
			SettingsActivity.this.startActivity(intent);
		}
	};
	
	ImageButton.OnClickListener btnBackOnClickListener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			finish();
		}
	};
	
	public void makeToast(String msg){
		Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_SHORT).show();
	}
	
	class UpdateEmail extends AsyncTask<String, Void, String> {
		String email;
		String apikey;
		boolean success = false;
		JSONObject responseOBJ;
		
		public UpdateEmail(String A,String E){
			email = E;
			apikey = A;
		}
		@Override protected void onPreExecute() {
			super.onPreExecute();
			/* TODO: display loading Animation */
		}
		@Override protected String doInBackground(String... urls) {
			
			/* TODO: prepare post parms */
			/* TODO: make post request */
			
			Log.d("APIKEY",apikey);
			Log.d("NEW EMAIL",email);
			
			Authenticator.setDefault(new Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication(){
					return new PasswordAuthentication(getString(R.string.wheatley_username)
							,getString(R.string.wheatley_password).toCharArray());
				}
			});
			
			String postParms = "type=update&key="+apikey+"&email="+email;
			
			success =  attempt(postParms);
			
			return "";
		}
		private Boolean attempt(String postParms) {
			//check via http request to API if login is valid
			String response;
			URL url;
			try {
				url = new URL(getString(R.string.api_url));
			} catch (MalformedURLException e) {
				Log.e("setUrl", Log.getStackTraceString(e));
				return false;
			}
			success = false;
			
			HttpURLConnection connection = null;
			try {
				connection = (HttpURLConnection) url.openConnection();
				
				connection.setRequestMethod("POST");
				connection.setRequestProperty("Content-Type", "application/json");
				
				OutputStream out = connection.getOutputStream();
				writeStream(out, postParms);
				
				connection.connect();
				
				Log.d("ResponseCode2",Integer.toString(connection.getResponseCode()));
				
				InputStream in;
				
				if(connection.getResponseCode() == HttpURLConnection.HTTP_OK){
					in= new BufferedInputStream(connection.getInputStream());
				}
				else{
					in = new BufferedInputStream(connection.getErrorStream());
				}
				
				response = readStream(in);
				Log.e("RESPONSE", response);
				
				responseOBJ = new JSONObject(response);
				
				if(responseOBJ.getString("status").equals("success")){
					success = true;
				} else {
					success = false;
				}
				
			} catch (Exception e) {
				Log.e("httpTest", Log.getStackTraceString(e));
				success = false;
			} finally {
				
				if (connection != null) {
					connection.disconnect();
				}
			}
			return success;
		}
		
		@Override protected void onPostExecute(String response) {
			if(responseOBJ == null){
				Log.e("JSON","responseOBJ is NULL");
				makeToast(getString(R.string.serverErrorMessage));
				return;
			}
			
			if (success) {
				SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
				SharedPreferences.Editor editor = sharedPref.edit();
				
				editor.putString(getString(R.string.key_Email),email);
				editor.apply();
				
				makeToast(getString(R.string.SettingsSavedSuccessfully));
				
				finish();
			} else {
				//login failed
				makeToast(getString(R.string.serverErrorMessage));
			}
		}
		
		private void writeStream(OutputStream out, String parms) throws IOException {
			BufferedWriter writer = new BufferedWriter(
					new OutputStreamWriter(out, "UTF-8"));
			writer.write(parms);
			writer.flush();
			writer.close();
		}
		private String readStream(InputStream ins) throws IOException {
			BufferedReader in = new BufferedReader(new InputStreamReader(ins));
			String result = "";
			String response;
			int i = 0;
			while ((response = in.readLine()) != null){
				result = result + response;
			}
			in.close();
			return result;
		}
		
	}
}
