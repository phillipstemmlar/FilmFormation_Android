package com.COS216.u18171185;

import android.app.Activity;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.StringRes;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.support.design.widget.TextInputLayout;
import android.util.Log;
import android.view.*;
import android.widget.*;
import android.content.Intent;
import android.os.AsyncTask;
import java.io.BufferedInputStream;
import java.io.OutputStreamWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Authenticator;
import java.net.MalformedURLException;
import java.net.PasswordAuthentication;
import java.net.URL;
import android.preference.PreferenceManager;
import com.COS216.u18171185.R;

import org.json.JSONObject;

import java.net.HttpURLConnection;

public class LoginActivity extends AppCompatActivity {

	EditText emailEditText;
	EditText passwordEditText;
	Button loginButton;
	
	ImageButton btnTogglePassword;
	
	TextView loginFailedText;
	CheckBox keepMeLoggedCheckBox;

	String logEmail = "";
	String logApikey = "";

	boolean showPassword;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		
		showPassword = false;
		
		emailEditText = findViewById(R.id.edtEmail);
		
		passwordEditText = findViewById(R.id.edtPassword);
		passwordEditText.setOnFocusChangeListener(passwordOnFocus);
		passwordEditText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
		
		loginButton = findViewById(R.id.btnLogin);
		loginFailedText = findViewById(R.id.txtLoginFailed);
		keepMeLoggedCheckBox = findViewById(R.id.cbxKeepMeLoggedIn);
		
		btnTogglePassword = findViewById(R.id.txtTogglePassword);
		btnTogglePassword.setImageResource(R.drawable.ic_visibility);
		btnTogglePassword.setOnClickListener(btnTogglePasswordOnClick);
		
		btnTogglePassword.setVisibility(View.GONE);
		
		loginFailedText.setText("");
		
	}

	EditText.OnFocusChangeListener passwordOnFocus = new View.OnFocusChangeListener(){
		@Override
		public void onFocusChange(View v, boolean hasFocus) {
			if(hasFocus){
				btnTogglePassword.setVisibility(View.VISIBLE);
			}else{
				btnTogglePassword.setVisibility(View.GONE);
			}
		}
	};
	
	ImageButton.OnClickListener btnTogglePasswordOnClick = new View.OnClickListener() {
		@Override public void onClick(View v) {
			if(showPassword){
				btnTogglePassword.setImageResource(R.drawable.ic_visibility_off);
				passwordEditText.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
			}else{
				btnTogglePassword.setImageResource(R.drawable.ic_visibility);
				passwordEditText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
			}
			passwordEditText.setSelection(passwordEditText.length());
			showPassword = !showPassword;
		}
	};
	
	public void btnLoginClicked (View view){
		String email = emailEditText.getText().toString();
		String password = passwordEditText.getText().toString();

		//email = "peterParker@gmail.com";
		//password = "PETERparker1234!@#$";
		
		//apikey = 5d5c2eb512032dd69ca0
		
		loginFailedText.setText("");
		AttemptLogin attemptLogin = new AttemptLogin(email,password);
		attemptLogin.execute();
	}

	@Override public boolean onKeyDown(int keyCode, KeyEvent event)  {
		if (Integer.parseInt(android.os.Build.VERSION.SDK) > 5
				&& keyCode == KeyEvent.KEYCODE_BACK
				&& event.getRepeatCount() == 0) {
			onBackPressed();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
	@Override public void onBackPressed() {
		Intent intent = new Intent();
		intent.putExtra("status",false);
		setResult(RESULT_OK, intent);
		finish();
	}

	class AttemptLogin extends AsyncTask<String, Void, String> {
		String email;
		String password;
		boolean success = false;
		JSONObject responseOBJ;
		
		public AttemptLogin(String E, String P){
			email = E;
			password = P;
		}
		@Override protected void onPreExecute() {
			super.onPreExecute();
			/* TODO: display loading Animation */
		}
		@Override protected String doInBackground(String... urls) {

			/* TODO: prepare post parms */
			/* TODO: make post request */

			Log.d("EMAIL",email);
			Log.d("PASSWORD",password);
			
			Authenticator.setDefault(new Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication(){
					return new PasswordAuthentication(getString(R.string.wheatley_username)
							,getString(R.string.wheatley_password).toCharArray());
				}
			});
			
			String postParms = "type=login&email="+email+"&password="+password+"&return[]=key&return[]=email&return[]=pref_Genre&return[]=pref_Year&return[]=pref_Rating";
			
			success =  attempt(postParms);
			
			return "";
		}
		private Boolean attempt(String postParms) {
			//check via http request to API if login is valid
			String response;
			URL url;
			try {
				url = new URL(getString(R.string.api_url));
			} catch (MalformedURLException e) {
				Log.e("setUrl", Log.getStackTraceString(e));
				return false;
			}
			success = false;
			
			HttpURLConnection connection = null;
			try {
				connection = (HttpURLConnection) url.openConnection();
				
				connection.setRequestMethod("POST");
				connection.setRequestProperty("Content-Type", "application/json");
				
				OutputStream out = connection.getOutputStream();
				writeStream(out, postParms);
				
				connection.connect();
				
				Log.d("ResponseCode2",Integer.toString(connection.getResponseCode()));
				
				InputStream in;
				
				if(connection.getResponseCode() == HttpURLConnection.HTTP_OK){
					in= new BufferedInputStream(connection.getInputStream());
				}
				else{
					in = new BufferedInputStream(connection.getErrorStream());
				}

				response = readStream(in);
				Log.e("RESPONSE", response);
				
				responseOBJ = new JSONObject(response);
				
				if(responseOBJ.getString("status").equals("success")){
					success = true;
				} else {
					success = false;
				}
				
			} catch (Exception e) {
				Log.e("httpTest", Log.getStackTraceString(e));
				success = false;
			} finally {
				
				if (connection != null) {
					connection.disconnect();
				}
			}
			return success;
		}
		
		@Override protected void onPostExecute(String response) {
			if(responseOBJ == null){
				Log.e("JSON","responseOBJ is NULL");
				loginFailedText.setText(R.string.serverErrorMessage);
				return;
			}
			
			String genre;
			String year;
			String rating;
			
			if (success) {
				try {
					JSONObject data = responseOBJ.getJSONObject("data");
					
					logEmail = data.getString("email");
					logApikey = data.getString("key");
					
					genre = data.getString("pref_Genre");
					year = data.getString("pref_Year");
					rating = data.getString("pref_Rating");
				}
				catch(Exception e){
					Log.e("JSON",Log.getStackTraceString(e));
					loginFailedText.setText(R.string.serverErrorMessage);
					return;
				}
				
				SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
				SharedPreferences.Editor editor = sharedPref.edit();
				
				editor.putString(getString(R.string.key_Email),logEmail);
				editor.putString(getString(R.string.key_ApiKey),logApikey);
				
				editor.putString(getString(R.string.key_Genre),genre);
				editor.putString(getString(R.string.key_Rating),rating);
				editor.putString(getString(R.string.key_Year),year);
				
				boolean stayLoggedIn = false;
				if (keepMeLoggedCheckBox.isChecked()) {
					stayLoggedIn = true;
				}
				editor.putBoolean(getString(R.string.key_KeepMeLoggedIn),stayLoggedIn);
				
				editor.commit();

				finish();
			} else {
				//login failed
				loginFailedText.setText(R.string.loginFailedMessage);
			}
		}
		
		private void writeStream(OutputStream out, String parms) throws IOException {
			BufferedWriter writer = new BufferedWriter(
					new OutputStreamWriter(out, "UTF-8"));
			writer.write(parms);
			writer.flush();
			writer.close();
		}
		private String readStream(InputStream ins) throws IOException {
			BufferedReader in = new BufferedReader(new InputStreamReader(ins));
			String result = "";
			String response;
			int i = 0;
			while ((response = in.readLine()) != null){
				result = result + response;
			}
			in.close();
			return result;
		}

	}
}
