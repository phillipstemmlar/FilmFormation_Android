package com.COS216.u18171185;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.net.URL;

public class MovieActivity extends AppCompatActivity {

    ImageButton btnBack;

    ImageView imgPoster;
    
    TextView txtTitle;
    TextView txtRelease;
    TextView txtRating;
    TextView txtGenre;
    TextView txtAgeRating;
    TextView txtPlot;

    String movieID;
    String posterURL;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie);

        txtTitle = findViewById(R.id.txtMovieTitle);
        txtRelease = findViewById(R.id.txtMovieRelease);
        txtRating = findViewById(R.id.txtMovieRating);
        txtGenre = findViewById(R.id.txtMovieGenre);
        txtAgeRating = findViewById(R.id.txtMovieAgeRating);
        txtPlot = findViewById(R.id.txtMoviePlot);
    
        imgPoster = findViewById(R.id.imgMoviePoster);
        
        btnBack = findViewById(R.id.btnMovieBack);
        btnBack.setOnClickListener(btnBackOnClickListener);
    
        setupInfo();
    }

    ImageButton.OnClickListener btnBackOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            finish();
        }
    };
    
    public void setupInfo(){
        Bundle args = getIntent().getExtras();
        movieID = args.getString("tmdbID", "null");
    
        txtTitle.setText(args.getString("title", "N/A"));
        txtRelease.setText(args.getString("release", "N/A"));
        txtGenre.setText(args.getString("genre", "N/A"));
        txtRating.setText(args.getString("rating", "N/A"));
        txtAgeRating.setText(args.getString("ageRating", "N/A"));
        txtPlot.setText(args.getString("plot", "N/A"));
    
        posterURL = args.getString("poster", "null");
        LoadImage loadImage = new LoadImage(posterURL);
        loadImage.execute();
    }
    
    class LoadImage extends AsyncTask<String, Void, String> {
        
        String httpURL;
        URL url;
        
        boolean success;
        Bitmap bmp;
        
        public LoadImage(String url_str){
            httpURL = url_str;
        }
        @Override protected void onPreExecute() {
            super.onPreExecute();
        }
        @Override protected String doInBackground(String... urls) {
            
            if(httpURL.equals("null")){ return ""; }
            
            success = false;
            try {
                url = new URL(httpURL);
                bmp = BitmapFactory.decodeStream(url.openConnection().getInputStream());
            }catch (Exception e){
                Log.e("IMAGE LOAD FAILED",Log.getStackTraceString(e));
            }
            
            return "";
        }
        @Override protected void onPostExecute(String response) {
            imgPoster.setImageBitmap(bmp);
        }
        
    }
}
