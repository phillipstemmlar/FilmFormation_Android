package com.COS216.u18171185;

import android.os.Bundle;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.*;
import android.widget.*;
import android.content.*;
import android.content.DialogInterface.*;
import android.app.AlertDialog;
import android.preference.PreferenceManager;
import com.COS216.u18171185.R;
import android.hardware.*;

public class MainActivity extends AppCompatActivity {
    
    BottomNavigationView navBottomTabs;

    Fragment discoverFrag;
    Fragment profileFrag;
	
	public ArrayAdapter adapter_g_names;
    public ArrayAdapter adapter_g_ids;
    public ArrayAdapter adapter_y;
    public ArrayAdapter adapter_r;
    
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private ShakeDetector shakeDetector;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    
        if(!isLoggedIn()){
            Intent intent = new Intent(this, LoginActivity.class);
            this.startActivityForResult ( intent ,1);
            
        }
    
        navBottomTabs = findViewById(R.id.nav_view);
        navBottomTabs.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        discoverFrag = new DiscoverFragment();
        profileFrag = new ProfileFragment();

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        Fragment discFrag = getSupportFragmentManager().findFragmentByTag("Discover");
        Fragment profFrag = getSupportFragmentManager().findFragmentByTag("Profile");

        if (discFrag == null) {
            fragmentTransaction.add(R.id.grpMainBody, discoverFrag, "Discover");
            fragmentTransaction.addToBackStack("Discover");
        }
        if (profFrag == null) {
            fragmentTransaction.add(R.id.grpMainBody, profileFrag, "Profile");
            fragmentTransaction.addToBackStack("Profile");
            fragmentTransaction.hide(profileFrag);
        }

        fragmentTransaction.commit();
        fragmentManager.executePendingTransactions();

        adapter_g_names = ArrayAdapter.createFromResource(MainActivity.this, R.array.filterGenresNames, R.layout.spinner_item);
        adapter_g_ids = ArrayAdapter.createFromResource(MainActivity.this, R.array.filterGenresIDs, R.layout.spinner_item);
        adapter_y = ArrayAdapter.createFromResource(MainActivity.this, R.array.filterYears, R.layout.spinner_item);
        adapter_r = ArrayAdapter.createFromResource(MainActivity.this, R.array.filterRatings, R.layout.spinner_item);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        shakeDetector = new ShakeDetector();
        shakeDetector.setOnShakeListener(new ShakeDetector.OnShakeListener() {
            @Override
            public void onShake(int count) {
                RefreshFeed();
            }
        });
    
    }
    
    public void RefreshFeed(){
        Fragment discFrag = getSupportFragmentManager().findFragmentByTag("Discover");
        if(discFrag != null){
            ((DiscoverFragment)discFrag).Refresh();
        }
    }
    
    @Override public void onResume(){
        super.onResume();
        sensorManager.registerListener(shakeDetector,accelerometer,SensorManager.SENSOR_DELAY_UI);
    }
    
    @Override public void onPause(){
        sensorManager.unregisterListener(shakeDetector);
        super.onPause();
    }
    
    public String getGenreID(int index){
        if(index == 1){
            SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
            String genre_id = sharedPref.getString(getString(R.string.key_Genre),getString(R.string.notLoggedIn));
            if(!genre_id.equals(getString(R.string.notLoggedIn))){
                index = adapter_g_ids.getPosition(genre_id);
                if(index < 2){ index = 0;}
            }else{
                index =0;
            }
        }
        return getResources().getStringArray(R.array.filterGenresIDs)[index];
    }
    public String getGenreName(int index){
        return getResources().getStringArray(R.array.filterGenresNames)[index];
    }
    public String getYear(int index){
        if(index == 1){
            SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
            String year = sharedPref.getString(getString(R.string.key_Year),getString(R.string.notLoggedIn));
            if(!year.equals(getString(R.string.notLoggedIn))){
                index = adapter_y.getPosition(year);
                if(index < 2){ index = 0;}
            }else{
                index =0;
            }
        }
        return getResources().getStringArray(R.array.filterYears)[index];
    }
    public String getRating(int index){
        if(index == 1){
            SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
            String rating = sharedPref.getString(getString(R.string.key_Rating),getString(R.string.notLoggedIn));
            if(!rating.equals(getString(R.string.notLoggedIn))){
                index = adapter_r.getPosition(rating);
                if(index < 2){ index = 0;}
            }else{
                index =0;
            }
        }
        return getResources().getStringArray(R.array.filterRatings)[index];
    }
    
    public void Logout(){
        PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).edit().clear().commit();
        goToDiscover();
    
        Fragment discFrag = getSupportFragmentManager().findFragmentByTag("Discover");
        if(discFrag != null){
            ((DiscoverFragment)discFrag).removeMovies();
        }
        
        recreate();
    }
    
    public void goToDiscover(){
        navBottomTabs.setSelectedItemId(R.id.action_discover);
        
        /*FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.grpMainBody, discoverFrag,"Discover");
        fragmentTransaction.commitNowAllowingStateLoss();*/
    }
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
			RefreshFeed();
        }
    }
    public Boolean isLoggedIn() {
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
    
        String Email = sharedPref.getString(getString(R.string.key_Email),getString(R.string.notLoggedIn));
        String Key = sharedPref.getString(getString(R.string.key_ApiKey),getString(R.string.notLoggedIn));
        boolean stayLoggedIn = sharedPref.getBoolean(getString(R.string.key_KeepMeLoggedIn),false);
        
        Log.e("Email",Email);
        Log.e("Key",Key);
        //Log.e("stayLoggedIn",stayLoggedIn.toString());
        
        if(Email.equals(getString(R.string.notLoggedIn)) || Key.equals(getString(R.string.notLoggedIn)))
        {
            return false;
        }
		return true;
    }
    @Override  public void onDestroy(){
        
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
    
        Boolean stayLoggedIn = sharedPref.getBoolean(getString(R.string.key_KeepMeLoggedIn),false);
    
        Log.e("stayLoggedIn onDestroy",stayLoggedIn.toString());
        
        if (!stayLoggedIn) {
            PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).edit().clear().commit();
        }
        
        super.onDestroy();
    }
    
    
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener(){
        @Override public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            Fragment fragShow, fragHide;
            String tag;
            
            /* TODO: If already at Discover and discover pressed then jump to top. */
            
            switch (item.getItemId()) {
                case R.id.action_discover:
                    fragShow = discoverFrag;
                    fragHide = profileFrag;//if(discoverFrag != null){
					Fragment discFrag = getSupportFragmentManager().findFragmentByTag("Filter");
					((FilterOptionsFragment)discFrag).loadPreferences();
					break;
                case R.id.action_profile:
                    fragShow = profileFrag;
                    fragHide = discoverFrag;
					if(profileFrag != null){ ((ProfileFragment)profileFrag).loadPreferences(); }
                    break;
                default:
                    fragShow = discoverFrag;
                    fragHide = profileFrag;
					Fragment discFrag1 = getSupportFragmentManager().findFragmentByTag("Filter");
					((FilterOptionsFragment)discFrag1).loadPreferences();
            }
            fragmentTransaction.show(fragShow);
            fragmentTransaction.hide(fragHide);
            fragmentTransaction.commit();
            return true;
        }
    };
    
    public void makeToast(String msg){
        Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_SHORT).show();
    }
    @Override public boolean onKeyDown(int keyCode, KeyEvent event)  {
        if (Integer.parseInt(android.os.Build.VERSION.SDK) > 5 && keyCode == KeyEvent.KEYCODE_BACK
        && event.getRepeatCount() == 0) {
            onBackPressed();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
    @Override  public void onBackPressed() {
        if (navBottomTabs.getSelectedItemId() == R.id.action_profile) {
            goToDiscover();
        } else if (navBottomTabs.getSelectedItemId() == R.id.action_discover){
            promptExit();
        }
        else{
            finish();
        }
    }
    private void promptExit(){
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setMessage(R.string.promptExit)
            .setTitle(R.string.exit)
            .setPositiveButton(R.string.yes,new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog,int id) {
                    MainActivity.this.finish();
                }})
            .setNegativeButton(R.string.no,new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog,int id) {
                    dialog.cancel();
                }
            });
        final AlertDialog dialog = builder.create();
        dialog.setOnShowListener( new OnShowListener() {
            @Override public void onShow(DialogInterface arg0) {
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(getResources().getColor(R.color.displayText_Black));
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(getResources().getColor(R.color.displayText_Black));
            }
        });
        dialog.show();
    }
}
