package com.COS216.u18171185;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.*;
import android.widget.*;

public class ProfileFragment extends Fragment {

    Activity activity;
    
    Button btnSettings;
    Button btnPreferences;
    ImageButton btnBack;
    Button btnLogout;
    
    TextView txtEmail;
    TextView txtApiKey;
    
    TextView txtGenre;
    TextView txtYear;
    TextView txtRating;
    
    String apikey = "";
    String email = "";
    
    String genreID = "";
    String year = "";
    String rating = "";
    
    @Nullable @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState){
        View fragmentView = inflater.inflate(R.layout.profile_layout, container, false);

        activity = getActivity();
    
        btnSettings = fragmentView.findViewById(R.id.btnChangePassword);
        btnSettings.setOnClickListener(btnSettingsClickListener);
        
        btnPreferences = fragmentView.findViewById(R.id.btnChangePreferences);
        btnPreferences.setOnClickListener(btnPreferencesClickListener);

        btnBack = fragmentView.findViewById(R.id.btnProfileBack);
        btnBack.setOnClickListener(btnBackClickListener);

        txtEmail = fragmentView.findViewById(R.id.txtProfileEmail);
        txtApiKey = fragmentView.findViewById(R.id.txtProfileApiKey);

        btnLogout = fragmentView.findViewById(R.id.btnLogout);
        btnLogout.setOnClickListener(btnLogoutClickListener);
        
        txtGenre = fragmentView.findViewById(R.id.txtPreferencesGenre);
        txtRating = fragmentView.findViewById(R.id.txtPreferencesRating);
        txtYear = fragmentView.findViewById(R.id.txtPreferencesYear);
        
        loadData();
        
        return fragmentView;
    }
    
    public void loadPreferences(){
        loadData();
    }
    
    private void Logout(){
        ((MainActivity)getActivity()).Logout();
    }
    
    private void goToDiscover(){
        ((MainActivity)getActivity()).goToDiscover();
    }

    private void loadData(){
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(((MainActivity)getActivity()).getApplicationContext());
    
        email = sharedPref.getString(getString(R.string.key_Email), getString(R.string.notLoggedIn));
        apikey = sharedPref.getString(getString(R.string.key_ApiKey), getString(R.string.notLoggedIn));

        genreID = sharedPref.getString(getString(R.string.key_Genre), getString(R.string.notLoggedIn));
        year = sharedPref.getString(getString(R.string.key_Year), getString(R.string.notLoggedIn));
        rating = sharedPref.getString(getString(R.string.key_Rating), getString(R.string.notLoggedIn));

        Log.e("Genre",genreID);
        Log.e("Year",year);
        Log.e("Rating",rating);

        
        txtEmail.setText(email);
        txtApiKey.setText(apikey);
        
        if(!genreID.equals(getString(R.string.notLoggedIn))) {
            int pos = (((MainActivity) getActivity())).adapter_g_ids.getPosition(genreID);
            if (pos < 0) {
                pos = 0;
            }
            genreID = ((MainActivity) getActivity()).getGenreName(pos);
        }
    
        txtGenre.setText(genreID);
        txtYear.setText(year);
        txtRating.setText(rating);
    }
    
    public String getGenreName_fromID(String id){
        String result = "No Filter";
        int genreCount = getResources().getStringArray(R.array.filterGenresNames).length;
        for(int i = 0; i < genreCount; i++){
            if(getResources().getStringArray(R.array.filterGenresIDs)[i] == id){
                result = getResources().getStringArray(R.array.filterGenresNames)[i];
                break;
            }
        }
        return result;
    }
    
    private Button.OnClickListener btnLogoutClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Logout();
        }
    };
    
    private Button.OnClickListener btnPreferencesClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent((MainActivity)getActivity(), PreferencesActivity.class);
            ((MainActivity)getActivity()).startActivity(intent);
        }
    };

    private Button.OnClickListener btnSettingsClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent((MainActivity)getActivity(), SettingsActivity.class);
            ((MainActivity)getActivity()).startActivity(intent);
        }
    };

    private Button.OnClickListener btnBackClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            goToDiscover();
        }
    };
    
    @Override
    public void onResume(){
        super.onResume();
        loadData();
    }
    
}
