package com.COS216.u18171185;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.*;
import android.widget.*;
import android.content.Intent;
import 	android.graphics.BitmapFactory;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.PasswordAuthentication;
import java.net.URL;
import com.COS216.u18171185.R;
import org.json.JSONArray;
import org.json.JSONObject;

public class MovieFragment extends Fragment{

    Activity activity;

    String movieID;
    String posterURL;
    
    ImageButton btnPoster;

    TextView txtTitle;
    TextView txtRelease;
    TextView txtRating;
    TextView txtGenre;
    TextView txtAgeRating;
    TextView txtPlot;

    @Nullable @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState){
        View fragmentView = inflater.inflate(R.layout.movie_layout, container, false);

        txtTitle = fragmentView.findViewById(R.id.txtTitle);
        txtRelease = fragmentView.findViewById(R.id.txtReleased);
        txtRating = fragmentView.findViewById(R.id.txtRating);
        txtGenre = fragmentView.findViewById(R.id.txtGenre);
        txtAgeRating = fragmentView.findViewById(R.id.txtAgeRating);
        txtPlot = fragmentView.findViewById(R.id.txtPlot);

        btnPoster = fragmentView.findViewById(R.id.imgPoster);
        btnPoster.setOnClickListener(btnPosterOnClickListener);
	
		setupInfo();
        
        return fragmentView;
    }

    ImageButton.OnClickListener btnPosterOnClickListener = new View.OnClickListener() {
        @Override public void onClick(View v) {
            Intent intent = new Intent((MainActivity)getActivity(), MovieActivity.class);
	
			Bundle bundle = new Bundle();
			bundle.putString("tmdbID", movieID);
			bundle.putString("title", txtTitle.getText().toString());
			bundle.putString("poster", posterURL);
			bundle.putString("release", txtRelease.getText().toString());
			bundle.putString("genre", txtGenre.getText().toString());
			bundle.putString("rating", txtRating.getText().toString());
			bundle.putString("ageRating", txtAgeRating.getText().toString());
			bundle.putString("plot", txtPlot.getText().toString());
   
			intent.putExtras(bundle);
            
            ((MainActivity)getActivity()).startActivity(intent);
        }
    };
    
    public void setupInfo(){
		Bundle args = getArguments();
		movieID = args.getString("tmdbID", "null");
		
		txtTitle.setText(args.getString("title", "N/A"));
		txtRelease.setText(args.getString("release", "N/A"));
		txtGenre.setText(args.getString("genre", "N/A"));
		txtRating.setText(args.getString("rating", "N/A"));
		txtAgeRating.setText(args.getString("ageRating", "N/A"));
		txtPlot.setText(args.getString("plot", "N/A"));
		
		posterURL = args.getString("poster", "null");
		LoadImage loadImage = new LoadImage(posterURL);
		loadImage.execute();
	}
	
	
	class LoadImage extends AsyncTask<String, Void, String> {
		
    	String httpURL;
    	URL url;
		
    	boolean success;
    	Bitmap bmp;
    	
		public LoadImage(String url_str){
			httpURL = url_str;
		}
		@Override protected void onPreExecute() {
			super.onPreExecute();
		}
		@Override protected String doInBackground(String... urls) {
			
			if(httpURL.equals("null")){ return ""; }
			
			success = false;
			try {
				url = new URL(httpURL);
				bmp = BitmapFactory.decodeStream(url.openConnection().getInputStream());
			}catch (Exception e){
				Log.e("IMAGE LOAD FAILED",Log.getStackTraceString(e));
			}
			
			return "";
		}
		@Override protected void onPostExecute(String response) {
			btnPoster.setImageBitmap(bmp);
		}
		
	}
	
}